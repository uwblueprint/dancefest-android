package com.uwblueprint.dancefest

import android.content.Intent
import android.os.Parcelable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.uwblueprint.dancefest.models.Adjudication
import com.uwblueprint.dancefest.models.Performance
import kotlinx.android.synthetic.main.item_performance.view.*

class PerformancesAdapter(
        private val adjudications: HashMap<*, *>,
        private val performances: ArrayList<Performance>,
        private val eventId: Int,
        private val eventTitle: String
) : RecyclerView.Adapter<PerformancesAdapter.ViewHolder>() {

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val performance = performances[position]
        holder.bindPerformance(performance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_performance, parent, false)
        return ViewHolder(itemView, adjudications)
    }

    override fun getItemCount() = performances.size

    class ViewHolder(v: View, private val adjudications: HashMap<*, *>)
        : RecyclerView.ViewHolder(v), View.OnClickListener {

        private val view: View = v
        private val danceEntryView: TextView = v.dance_entry_text
        private val nameView: TextView = v.name_performance
        private var performance: Performance? = null

        init {
            v.setOnClickListener(this)
        }

        fun bindPerformance(p: Performance) {
            performance = p
            danceEntryView.text = p.danceEntry.toString()
            nameView.text = p.danceTitle
        }

        override fun onClick(v: View) {
            val context = v.context
            val adjudication = adjudications[performance?.performanceId] as? Adjudication
            val intent = Intent(context, CritiqueFormActivity::class.java)
            if (adjudication != null) {
                intent.putExtra(PerformanceFragment.TAG_ADJUDICATION, adjudication)
            }
//            intent.putExtra(PerformanceActivity.TAG_EVENT_ID, eventID)
//            intent.putExtra(PerformanceActivity.TAG_TITLE, eventTitle)
//            intent.putExtra(PerformanceFragment.TAG_PERFORMANCE, performance as Parcelable)
//            intent.putExtra(PerformanceActivity.TAG_TABLET_ID, tabletID)
//            startActivity(intent)
        }
    }
}
