package com.uwblueprint.dancefest.api

import com.uwblueprint.dancefest.models.*
import retrofit2.Call
import retrofit2.http.*

interface DancefestService {

    // Events
    @GET("/events")
    fun getEvents(): Call<Map<String, Event>>

    // Performances
    @GET("/events/{eventId}/performances")
    fun getPerformances(@Path("eventId") eventId: Int): Call<Map<String, Performance>>

    // Adjudications
    @GET("/performances/{performanceId}/adjudications")
    fun getAdjudications(@Path("performanceId") performanceId: Int,
                         @Query("tablet_id") tabletId: Int): Call<Map<String, Adjudication>>

    @POST("/performances/{performanceId}/adjudications")
    fun createAdjudication(@Path("performanceId") performanceId: Int,
                           @Body adjudication: AdjudicationPost): Call<Adjudication>

    @POST("/adjudications/{adjudicationId}")
    fun updateAdjudication(@Path("adjudicationId") adjudicationId: Int,
                           @Body adjudication: AdjudicationPost): Call<Adjudication>

    // Tablet
    @GET("/tablets/{tabletSerial}")
    fun getOrCreateTablet(@Path("tabletSerial") tabletSerial: String): Call<Tablet>
}
